/* MAIN USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"
#include <string.h>
#include <stdio.h>
#include "tim.h"
#include "gpio.h"
#include "traffic_shared.h"
#include "core_cm4.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */



/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;


extern osThreadId defaultTaskHandle;
extern osThreadId TrafficTaskHandle;
extern osThreadId SensorTaskHandle;
extern osThreadId PedestrianTaskHandle;
extern osThreadId DisplayTaskHandle;
extern osMessageQId SensorQueueHandle;
extern osMessageQId PedQueueHandle;
extern osMutexId StateMutexHandle;
extern osSemaphoreId PedRequestHandle;
extern osSemaphoreId TrafficDensitySem1Handle;
extern osSemaphoreId TrafficDensitySem2Handle;
extern osSemaphoreId TrafficDensitySem3Handle;
extern osSemaphoreId TrafficDensitySem4Handle;
extern osSemaphoreId TimingSemHandle;

/* USER CODE BEGIN PV */


/* buffers */

volatile uint32_t last_measured_us[DIR_COUNT];    // duration
volatile uint8_t  sensor_ready[DIR_COUNT];        // set to 1 by ISR

/* Keep track of rising capture values */
volatile uint32_t capture_rising_val[DIR_COUNT];
volatile uint8_t  waiting_for_falling[DIR_COUNT];

/* Shared traffic state */
traffic_state_t g_state = STATE_NS_GREEN;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
void StartDefaultTask(void const * argument);
void Traffic_Task(void const * argument);
void Sensor_Task(void const * argument);
void Pedestrian_Task(void const * argument);
void Display_Task(void const * argument);

/* USER CODE BEGIN PFP */

/* Utility */

static void DWT_Delay_Init(void);
static void delay_us(uint32_t us);
void trigger_sensor_gpio(direction_t dir);
static void process_capture(direction_t dir, uint32_t start, uint32_t end);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* DWT delay */
static void DWT_Delay_Init(void)
{
  /* Enable TRC */
  CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
  /* Enable CCNT */
  DWT->CYCCNT = 0;
  DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
}


/* delay in microseconds using cycle counter */
static void delay_us(uint32_t us)
{
  uint32_t cycles = (SystemCoreClock / 1000000UL) * us;
  uint32_t start = DWT->CYCCNT;
  while ((DWT->CYCCNT - start) < cycles) { __NOP(); }
}

/* trigger pulse */
void trigger_sensor_gpio(direction_t dir)
{
  GPIO_TypeDef* port;
  uint16_t pin;
  switch (dir) {
    case DIR_NORTH: port = TRIG_N_PORT; pin = TRIG_N_PIN; break;
    case DIR_SOUTH: port = TRIG_S_PORT; pin = TRIG_S_PIN; break;
    case DIR_EAST:  port = TRIG_E_PORT; pin = TRIG_E_PIN; break;
    case DIR_WEST:  port = TRIG_W_PORT; pin = TRIG_W_PIN; break;
    default: return;
  }
  HAL_GPIO_WritePin(port, pin, GPIO_PIN_RESET);
  delay_us(2);
  HAL_GPIO_WritePin(port, pin, GPIO_PIN_SET);
  delay_us(TRIG_PULSE_US);
  HAL_GPIO_WritePin(port, pin, GPIO_PIN_RESET);
}

/* compute pulse width and store */
static void process_capture(direction_t dir, uint32_t start, uint32_t end)
{
  uint32_t dur;

  if (end >= start) dur = end - start;
  else dur = (60000UL - start) + end;
  last_measured_us[dir] = dur;
  sensor_ready[dir] = 1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/
  HAL_Init();

  /* USER CODE BEGIN Init */
  DWT_Delay_Init();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();

  GPIO_InitTypeDef GPIO_InitStruct = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();

  /* USER CODE BEGIN 2 */


  /* TIM1 channels 2 and 4 (north, south) */
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_2);
  HAL_TIM_IC_Start_IT(&htim1, TIM_CHANNEL_4);

  /* TIM3 channel 2 (east) */
  HAL_TIM_Base_Start(&htim3);
  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_2);

  /* TIM4 channel 2 (west) */
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_2);

  /* Initialize capture state arrays */
  for (int i = 0; i < DIR_COUNT; ++i) {
    sensor_ready[i] = 0;
    last_measured_us[i] = 0;
    capture_rising_val[i] = 0;
    waiting_for_falling[i] = 0;
  }

  /* USER CODE END 2 */


  /* StateMutex */
  osMutexDef(StateMutex);
  StateMutexHandle = osMutexCreate(osMutex(StateMutex));

  /* USER CODE BEGIN RTOS_MUTEX */

  /* USER CODE END RTOS_MUTEX */

  /* Semaphores(s) */


  osSemaphoreDef(PedRequest);
  PedRequestHandle = osSemaphoreCreate(osSemaphore(PedRequest), 1);



  osSemaphoreDef(TrafficDensitySem1);
  TrafficDensitySem1Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem1), 1);
  osSemaphoreDef(TrafficDensitySem2);
  TrafficDensitySem2Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem2), 1);
  osSemaphoreDef(TrafficDensitySem3);
  TrafficDensitySem3Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem3), 1);
  osSemaphoreDef(TrafficDensitySem4);
  TrafficDensitySem4Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem4), 1);

  /*(optional timing semaphore) */
  osSemaphoreDef(TimingSem);
  TimingSemHandle = osSemaphoreCreate(osSemaphore(TimingSem), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */


  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the queue(s) */

  {
    osMessageQDef(SensorQueue, SENSOR_QUEUE_LENGTH, echo_msg_t);
    SensorQueueHandle = osMessageCreate(osMessageQ(SensorQueue), NULL);
  }
  /* PedQueue */
  {
    osMessageQDef(PedQueue, PED_QUEUE_LENGTH, ped_msg_t);
    PedQueueHandle = osMessageCreate(osMessageQ(PedQueue), NULL);
  }

  /* USER CODE BEGIN RTOS_QUEUES */

  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* TrafficTask */
  osThreadDef(TrafficTask, Traffic_Task, osPriorityNormal, 0, 512);
  TrafficTaskHandle = osThreadCreate(osThread(TrafficTask), NULL);

  /* SensorTask */
  osThreadDef(SensorTask, Sensor_Task, osPriorityNormal, 0, 512);
  SensorTaskHandle = osThreadCreate(osThread(SensorTask), NULL);

  /* PedestrianTask */
  osThreadDef(PedestrianTask, Pedestrian_Task, osPriorityHigh, 0, 512);
  PedestrianTaskHandle = osThreadCreate(osThread(PedestrianTask), NULL);

  /*DisplayTask */
  osThreadDef(DisplayTask, Display_Task, osPriorityLow, 0, 256);
  DisplayTaskHandle = osThreadCreate(osThread(DisplayTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */

  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();




  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */
    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}



void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
  uint32_t captured;
  /* timer and channel triggered */
  if (htim->Instance == TIM1) {
    /* TIM1 CH2 (north) or CH4 (south) */
    if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) {
      /* North sensor */
      captured = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
      if (waiting_for_falling[DIR_NORTH] == 0) {
        /* rising edge captured */
        capture_rising_val[DIR_NORTH] = captured;
        waiting_for_falling[DIR_NORTH] = 1;
        /* switch to falling polarity */
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
      } else {
        /* falling edge captured */
        process_capture(DIR_NORTH, (uint32_t)capture_rising_val[DIR_NORTH], captured);
        waiting_for_falling[DIR_NORTH] = 0;
        /* restore rising polarity */
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
      }
    } else if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_4) {
      /* South sensor */
      captured = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_4);
      if (waiting_for_falling[DIR_SOUTH] == 0) {
        capture_rising_val[DIR_SOUTH] = captured;
        waiting_for_falling[DIR_SOUTH] = 1;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_FALLING);
      } else {
        process_capture(DIR_SOUTH, (uint32_t)capture_rising_val[DIR_SOUTH], captured);
        waiting_for_falling[DIR_SOUTH] = 0;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_4, TIM_INPUTCHANNELPOLARITY_RISING);
      }
    }
  } else if (htim->Instance == TIM3) {
    /* TIM3 CH2 (east) */
    if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) {
      captured = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
      if (waiting_for_falling[DIR_EAST] == 0) {
        capture_rising_val[DIR_EAST] = captured;
        waiting_for_falling[DIR_EAST] = 1;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
      } else {
        process_capture(DIR_EAST, (uint32_t)capture_rising_val[DIR_EAST], captured);
        waiting_for_falling[DIR_EAST] = 0;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
      }
    }
  } else if (htim->Instance == TIM4) {
    /* TIM4 CH2 (west) */
    if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_2) {
      captured = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_2);
      if (waiting_for_falling[DIR_WEST] == 0) {
        capture_rising_val[DIR_WEST] = captured;
        waiting_for_falling[DIR_WEST] = 1;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_FALLING);
      } else {
        process_capture(DIR_WEST, (uint32_t)capture_rising_val[DIR_WEST], captured);
        waiting_for_falling[DIR_WEST] = 0;
        __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_2, TIM_INPUTCHANNELPOLARITY_RISING);
      }
    }
  }
}



void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  /* Buttons on PC8 - PC11 */
  if (GPIO_Pin == BTN_N_PIN || GPIO_Pin == BTN_S_PIN || GPIO_Pin == BTN_E_PIN || GPIO_Pin == BTN_W_PIN) {
    ped_msg_t p;
    if (GPIO_Pin == BTN_N_PIN) p.dir = DIR_NORTH;
    else if (GPIO_Pin == BTN_S_PIN) p.dir = DIR_SOUTH;
    else if (GPIO_Pin == BTN_E_PIN) p.dir = DIR_EAST;
    else p.dir = DIR_WEST;

    /*  PedQueue */
    osMessagePut(PedQueueHandle, (uint32_t)&p, 0);

    osSemaphoreRelease(PedRequestHandle);
  }
}
/* USER CODE END 4 */



/* IRQ Handlers */
void EXTI4_IRQHandler(void)  { HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_4); }
void EXTI9_5_IRQHandler(void){ HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_5); HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_6); HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_7); }
void EXTI15_10_IRQHandler(void){ HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_10); HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_11); HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8); HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_9); }

/* USER CODE BEGIN 6 */

/* USER CODE END 6 */

void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};


  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);


  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

    RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
/* End of user code */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
