/* FreeRTOS USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"
#include "traffic_shared.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#define NORMAL_GREEN_MS     15000
#define REDUCED_GREEN_MS     7500
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
osThreadId defaultTaskHandle;
osThreadId TrafficTaskHandle;
osThreadId SensorTaskHandle;
osThreadId PedestrianTaskHandle;
osThreadId DisplayTaskHandle;
osMessageQId SensorQueueHandle;
osMessageQId PedQueueHandle;
osMutexId StateMutexHandle;
osSemaphoreId PedRequestHandle;
osSemaphoreId TrafficDensitySem1Handle;
osSemaphoreId TrafficDensitySem2Handle;
osSemaphoreId TrafficDensitySem3Handle;
osSemaphoreId TrafficDensitySem4Handle;
osSemaphoreId TimingSemHandle;

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void const * argument);
void Traffic_Task(void const * argument);
void Sensor_Task(void const * argument);
void Pedestrian_Task(void const * argument);
void Display_Task(void const * argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */


void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize );

/* USER CODE BEGIN GET_IDLE_TASK_MEMORY */
static StaticTask_t xIdleTaskTCBBuffer;
static StackType_t xIdleStack[configMINIMAL_STACK_SIZE];
volatile uint8_t pedestrian_request[DIR_COUNT] = {0};

void vApplicationGetIdleTaskMemory( StaticTask_t **ppxIdleTaskTCBBuffer, StackType_t **ppxIdleTaskStackBuffer, uint32_t *pulIdleTaskStackSize )
{
  *ppxIdleTaskTCBBuffer = &xIdleTaskTCBBuffer;
  *ppxIdleTaskStackBuffer = &xIdleStack[0];
  *pulIdleTaskStackSize = configMINIMAL_STACK_SIZE;

}
/* USER CODE END GET_IDLE_TASK_MEMORY */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* StateMutex */
  osMutexDef(StateMutex);
  StateMutexHandle = osMutexCreate(osMutex(StateMutex));

  /* USER CODE BEGIN RTOS_MUTEX */

  /* USER CODE END RTOS_MUTEX */


  /* PedRequest */
  osSemaphoreDef(PedRequest);
  PedRequestHandle = osSemaphoreCreate(osSemaphore(PedRequest), 1);

  /* TrafficDensitySem1 */
  osSemaphoreDef(TrafficDensitySem1);
  TrafficDensitySem1Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem1), 1);

  /* TrafficDensitySem2 */
  osSemaphoreDef(TrafficDensitySem2);
  TrafficDensitySem2Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem2), 1);

  /* TrafficDensitySem3 */
  osSemaphoreDef(TrafficDensitySem3);
  TrafficDensitySem3Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem3), 1);

  /* TrafficDensitySem4 */
  osSemaphoreDef(TrafficDensitySem4);
  TrafficDensitySem4Handle = osSemaphoreCreate(osSemaphore(TrafficDensitySem4), 1);

  /* TimingSem */
  osSemaphoreDef(TimingSem);
  TimingSemHandle = osSemaphoreCreate(osSemaphore(TimingSem), 1);

  /* USER CODE BEGIN RTOS_SEMAPHORES */

  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */

  /* USER CODE END RTOS_TIMERS */


  /* SensorQueue */
  osMessageQDef(SensorQueue, 4, uint16_t);
  SensorQueueHandle = osMessageCreate(osMessageQ(SensorQueue), NULL);

  /* PedQueue */
  osMessageQDef(PedQueue, 4, uint16_t);
  PedQueueHandle = osMessageCreate(osMessageQ(PedQueue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */

  /* USER CODE END RTOS_QUEUES */


  /* defaultTask */
  osThreadDef(defaultTask, StartDefaultTask, osPriorityNormal, 0, 128);
  defaultTaskHandle = osThreadCreate(osThread(defaultTask), NULL);

  /* TrafficTask */
  osThreadDef(TrafficTask, Traffic_Task, osPriorityNormal, 0, 512);
  TrafficTaskHandle = osThreadCreate(osThread(TrafficTask), NULL);

  /* SensorTask */
  osThreadDef(SensorTask, Sensor_Task, osPriorityNormal, 0, 512);
  SensorTaskHandle = osThreadCreate(osThread(SensorTask), NULL);

  /* PedestrianTask */
  osThreadDef(PedestrianTask, Pedestrian_Task, osPriorityHigh, 0, 512);
  PedestrianTaskHandle = osThreadCreate(osThread(PedestrianTask), NULL);

  /* DisplayTask */
  osThreadDef(DisplayTask, Display_Task, osPriorityLow, 0, 256);
  DisplayTaskHandle = osThreadCreate(osThread(DisplayTask), NULL);

  /* USER CODE BEGIN RTOS_THREADS */

  /* USER CODE END RTOS_THREADS */

}


void StartDefaultTask(void const * argument)
{

  for(;;)
  {
    osDelay(1);
  }

}


void Traffic_Task(void const * argument)
{
    (void) argument;
    echo_msg_t sensorMsg;
    uint32_t vehicle_count;
    uint32_t ns_green_ms, ew_green_ms;
    traffic_state_t local_state;

    for (;;)
    {
        /* Drain all available sensor messages and count vehicles */
        vehicle_count = 0;
        osEvent evt;
        while (1)
        {
            evt = osMessageGet(SensorQueueHandle, 0);
            if (evt.status != osEventMessage) break;
            break; // drain quickly
        }

        /* Count vehicles from ultrasonic sensors */
        for (int d = 0; d < DIR_COUNT; d++)
        {
            if (sensor_ready[d])
            {
                float cm = ((float)last_measured_us[d]) / 58.0f;
                float inch = cm / INCH_TO_CM;
                if (inch <= SENSOR_TRIGGER_DIST_INCH)
                {
                    vehicle_count++;
                    if (d == DIR_NORTH) osSemaphoreRelease(TrafficDensitySem1Handle);
                    else if (d == DIR_SOUTH) osSemaphoreRelease(TrafficDensitySem2Handle);
                    else if (d == DIR_EAST)  osSemaphoreRelease(TrafficDensitySem3Handle);
                    else if (d == DIR_WEST)  osSemaphoreRelease(TrafficDensitySem4Handle);
                }
                sensor_ready[d] = 0;
            }
        }

        /* Compute base green durations */
        if (vehicle_count > 0) {
            ns_green_ms = (GREEN_SENSOR_HIGH_MIN + GREEN_SENSOR_HIGH_MAX) / 2;
            ew_green_ms = (GREEN_SENSOR_HIGH_MIN + GREEN_SENSOR_HIGH_MAX) / 2;
        } else {
            ns_green_ms = (GREEN_BASE_MS_MIN + GREEN_BASE_MS_MAX) / 2;
            ew_green_ms = (GREEN_BASE_MS_MIN + GREEN_BASE_MS_MAX) / 2;
        }

        /* Check pedestrian flags to shorten next opposite direction */
        if (pedestrian_request[DIR_EAST] || pedestrian_request[DIR_WEST]) {
            ns_green_ms -= 5000;
            if (ns_green_ms < GREEN_PED_MIN) ns_green_ms = GREEN_PED_MIN;
            pedestrian_request[DIR_EAST] = pedestrian_request[DIR_WEST] = 0;
        }
        if (pedestrian_request[DIR_NORTH] || pedestrian_request[DIR_SOUTH]) {
            ew_green_ms -= 5000;
            if (ew_green_ms < GREEN_PED_MIN) ew_green_ms = GREEN_PED_MIN;
            pedestrian_request[DIR_NORTH] = pedestrian_request[DIR_SOUTH] = 0;
        }

        /* Main State Machine*/

        /* north-south  */
        osMutexWait(StateMutexHandle, osWaitForever);
        g_state = STATE_NS_GREEN;
        osMutexRelease(StateMutexHandle);

        uint32_t start = HAL_GetTick();
        while ((HAL_GetTick() - start) < ns_green_ms)
        {
            if (osSemaphoreWait(PedRequestHandle, 0) == osOK) break;
            osDelay(100);
        }

        /* north-south yellow */
        osMutexWait(StateMutexHandle, osWaitForever);
        g_state = STATE_NS_YELLOW;
        osMutexRelease(StateMutexHandle);
        osDelay(YELLOW_MS);

        /* all red (clear */
        osDelay(INTERSECTION_DELAY_MS);

        /* east-west green */
        osMutexWait(StateMutexHandle, osWaitForever);
        g_state = STATE_EW_GREEN;
        osMutexRelease(StateMutexHandle);

        start = HAL_GetTick();
        while ((HAL_GetTick() - start) < ew_green_ms)
        {
            if (osSemaphoreWait(PedRequestHandle, 0) == osOK) break;
            osDelay(100);
        }

        /* east-west yellow */
        osMutexWait(StateMutexHandle, osWaitForever);
        g_state = STATE_EW_YELLOW;
        osMutexRelease(StateMutexHandle);
        osDelay(YELLOW_MS);

        /* all red (clear) */
        osDelay(INTERSECTION_DELAY_MS);
    }
}


/* Header_Sensor_Task */

void Sensor_Task(void const * argument)
{
	(void) argument;
	  echo_msg_t msg;

	  for (;;) {
	    /* Trigger sequence (north, south, east, west) */
	    trigger_sensor_gpio(DIR_NORTH);
	    osDelay(60); /* wait for echo to be captured by TIM1 */
	    if (sensor_ready[DIR_NORTH]) {
	      msg.dir = DIR_NORTH;
	      msg.duration_us = last_measured_us[DIR_NORTH];

	      osMessagePut(SensorQueueHandle, (uint32_t)&msg, 0);

	      sensor_ready[DIR_NORTH] = 0;
	    }

	    trigger_sensor_gpio(DIR_SOUTH);
	    osDelay(60);
	    if (sensor_ready[DIR_SOUTH]) {
	      msg.dir = DIR_SOUTH;
	      msg.duration_us = last_measured_us[DIR_SOUTH];
	      osMessagePut(SensorQueueHandle, (uint32_t)&msg, 0);
	      sensor_ready[DIR_SOUTH] = 0;
	    }

	    trigger_sensor_gpio(DIR_EAST);
	    osDelay(60);
	    if (sensor_ready[DIR_EAST]) {
	      msg.dir = DIR_EAST;
	      msg.duration_us = last_measured_us[DIR_EAST];
	      osMessagePut(SensorQueueHandle, (uint32_t)&msg, 0);
	      sensor_ready[DIR_EAST] = 0;
	    }

	    trigger_sensor_gpio(DIR_WEST);
	    osDelay(60);
	    if (sensor_ready[DIR_WEST]) {
	      msg.dir = DIR_WEST;
	      msg.duration_us = last_measured_us[DIR_WEST];
	      osMessagePut(SensorQueueHandle, (uint32_t)&msg, 0);
	      sensor_ready[DIR_WEST] = 0;
	    }

	    osDelay(SENSOR_TASK_PERIOD_MS);
	  }
}

/* Header_Pedestrian_Task */

void Pedestrian_Task(void const * argument)
{
    for (;;)
    {
        if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_8) == GPIO_PIN_RESET) pedestrian_request[DIR_NORTH] = 1;
        if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_9) == GPIO_PIN_RESET) pedestrian_request[DIR_SOUTH] = 1;
        if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_10) == GPIO_PIN_RESET) pedestrian_request[DIR_EAST]  = 1;
        if (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11) == GPIO_PIN_RESET) pedestrian_request[DIR_WEST]  = 1;
        osDelay(100);
    }
}


/* Header_Display_Task */

void Display_Task(void const * argument)
{
    (void) argument;
    traffic_state_t local_state;

    for (;;)
    {
        osMutexWait(StateMutexHandle, osWaitForever);
        local_state = g_state;
        osMutexRelease(StateMutexHandle);

        /* Turn OFF all LEDs */
        HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_10, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7, GPIO_PIN_RESET);

        switch (local_state)
        {
            /* north-south green */
            case STATE_NS_GREEN:
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6 | GPIO_PIN_5, GPIO_PIN_SET); // N & S Green
                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_10, GPIO_PIN_SET); // E & W Red

                // Pedestrian: East/North walk, West/South stop
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2 | GPIO_PIN_0, GPIO_PIN_SET);   // E + N walk ON
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1 | GPIO_PIN_3, GPIO_PIN_RESET); // S + W walk OFF
                break;

            /* north-south yellow */
            case STATE_NS_YELLOW:
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1 | GPIO_PIN_4, GPIO_PIN_SET); // N & S Yellow
                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0 | GPIO_PIN_10, GPIO_PIN_SET); // E & W Red

                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2 | GPIO_PIN_0, GPIO_PIN_SET);   // E + N walk ON
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1 | GPIO_PIN_3, GPIO_PIN_RESET); // S + W walk OFF
                break;

            /* east-west green */
            case STATE_EW_GREEN:
                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET);  // East Green
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET);  // West Green
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);  // North Red
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);  // South Red

                // pedestrian: west/south go, east/north stop
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1 | GPIO_PIN_3, GPIO_PIN_SET);   // S + W walk ON
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0 | GPIO_PIN_2, GPIO_PIN_RESET); // N + E walk OFF
                break;

            /* east-west yellow */
            case STATE_EW_YELLOW:
                HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);  // East Yellow
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET);  // West Yellow
                HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);  // North Red
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET);  // South Red

                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1 | GPIO_PIN_3, GPIO_PIN_SET);   // S + W walk ON
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0 | GPIO_PIN_2, GPIO_PIN_RESET); // N + E walk OFF
                break;
        }

        osDelay(DISPLAY_TASK_PERIOD_MS);
    }
}




/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */
