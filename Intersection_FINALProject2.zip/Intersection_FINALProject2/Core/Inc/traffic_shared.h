

#ifndef TRAFFIC_SHARED_H
#define TRAFFIC_SHARED_H

#include "main.h"
#include "cmsis_os.h"

/* shared constants  */
#define GREEN_BASE_MS_MIN        15000U
#define GREEN_BASE_MS_MAX        20000U
#define GREEN_SENSOR_HIGH_MIN     5000U
#define GREEN_SENSOR_HIGH_MAX    10000U
#define GREEN_PED_MIN            10000U
#define GREEN_PED_MAX            15000U
#define YELLOW_MS                 2000U
#define INTERSECTION_DELAY_MS      500U

#define SENSOR_TRIGGER_DIST_INCH   4.5f
#define INCH_TO_CM                 2.54f

#define TRIG_PULSE_US              10U
#define SENSOR_QUEUE_LENGTH         8
#define PED_QUEUE_LENGTH            8

#define SENSOR_TASK_PERIOD_MS      2000U
#define DISPLAY_TASK_PERIOD_MS      200U



/* shared types */

typedef enum {
  DIR_NORTH = 0,
  DIR_SOUTH,
  DIR_EAST,
  DIR_WEST,
  DIR_COUNT
} direction_t;

typedef struct {
  direction_t dir;
  uint32_t duration_us;
} echo_msg_t;

typedef struct {
  direction_t dir;
} ped_msg_t;

typedef enum {
  STATE_NS_GREEN,
  STATE_NS_YELLOW,
  STATE_EW_GREEN,
  STATE_EW_YELLOW
} traffic_state_t;

/* shared globals*/
extern volatile uint32_t last_measured_us[DIR_COUNT];
extern volatile uint8_t  sensor_ready[DIR_COUNT];
extern traffic_state_t g_state;
extern volatile uint8_t pedestrian_request[DIR_COUNT];// N, S, E, W

/* shared utility function */
void trigger_sensor_gpio(direction_t dir);

#endif /* TRAFFIC_SHARED_H */



