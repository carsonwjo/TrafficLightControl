/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */


#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* includes*/
#include "stm32f4xx_hal.h"


/* GPIO DEFINITIONS */

/* ultrasonic trigger outs  */
#define TRIG_N_PORT      GPIOA
#define TRIG_N_PIN       GPIO_PIN_0

#define TRIG_S_PORT      GPIOA
#define TRIG_S_PIN       GPIO_PIN_1

#define TRIG_E_PORT      GPIOA
#define TRIG_E_PIN       GPIO_PIN_2

#define TRIG_W_PORT      GPIOA
#define TRIG_W_PIN       GPIO_PIN_3

/*  ultrasonic echo pins */
/* TIM1 CH2 - PA9 (North) */
#define ECHO_N_PORT      GPIOA
#define ECHO_N_PIN       GPIO_PIN_9

/* TIM1 CH4 - PA11 (South) */
#define ECHO_S_PORT      GPIOA
#define ECHO_S_PIN       GPIO_PIN_11

/* TIM3 CH2 - PA7 (East) */
#define ECHO_E_PORT      GPIOA
#define ECHO_E_PIN       GPIO_PIN_7

/* TIM4 CH2 - PB7 (West) */
#define ECHO_W_PORT      GPIOB
#define ECHO_W_PIN       GPIO_PIN_7

/* traffic lights*/

/* north */
#define N_RED_PORT       GPIOB
#define N_RED_PIN        GPIO_PIN_0
#define N_YEL_PORT       GPIOB
#define N_YEL_PIN        GPIO_PIN_1
#define N_GRN_PORT       GPIOB
#define N_GRN_PIN        GPIO_PIN_2

/* south */
#define S_RED_PORT       GPIOB
#define S_RED_PIN        GPIO_PIN_3
#define S_YEL_PORT       GPIOB
#define S_YEL_PIN        GPIO_PIN_4
#define S_GRN_PORT       GPIOB
#define S_GRN_PIN        GPIO_PIN_5

/* east */
#define E_RED_PORT       GPIOC
#define E_RED_PIN        GPIO_PIN_0
#define E_YEL_PORT       GPIOC
#define E_YEL_PIN        GPIO_PIN_1
#define E_GRN_PORT       GPIOC
#define E_GRN_PIN        GPIO_PIN_2

/* west */
#define W_RED_PORT       GPIOC
#define W_RED_PIN        GPIO_PIN_3
#define W_YEL_PORT       GPIOC
#define W_YEL_PIN        GPIO_PIN_4
#define W_GRN_PORT       GPIOC
#define W_GRN_PIN        GPIO_PIN_5

/* pedestrian lights */
#define P_N_PORT         GPIOD
#define P_N_PIN          GPIO_PIN_0
#define P_S_PORT         GPIOD
#define P_S_PIN          GPIO_PIN_1
#define P_E_PORT         GPIOD
#define P_E_PIN          GPIO_PIN_2
#define P_W_PORT         GPIOD
#define P_W_PIN          GPIO_PIN_3




/* USER CODE END Includes */

/* pedestrian buttons */
#define BTN_N_PORT GPIOC
#define BTN_N_PIN  GPIO_PIN_8

#define BTN_S_PORT GPIOC
#define BTN_S_PIN  GPIO_PIN_9

#define BTN_E_PORT GPIOC
#define BTN_E_PIN  GPIO_PIN_10

#define BTN_W_PORT GPIOC
#define BTN_W_PIN  GPIO_PIN_11


/* Exported functions prototypes */
void Error_Handler(void);



/* private defines */
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB



#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
